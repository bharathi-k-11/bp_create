sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("fiori.bp.team4.BaseController",{oCore:sap.ui.getCore()})});
//# sourceMappingURL=BaseController.js.map